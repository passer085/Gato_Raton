//mpicc gatoraton.c -o gatoraton
//mpirun -np 4 gatoraton
//4 es el numero de procesos


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>

#define root 0

#define matrixRows 3

#define matrixColumns 4

#define totalMatrix (matrixRows*matrixColumns)


void elegirCasilla(int laberinto[matrixRows][matrixColumns], int propio[2], int rank){
	//1) averiguar a que casillas me puedo mover por posibles limites de la matriz
	int posibles[8*2];
	int reales[8*2];
	int index = 0;
	int indexReal = 0;
	int x = propio[0];
	int y = propio[1];
	//printf("x:%d y:%d  ",x,y);

	if(x-1 >= 0){
		if(y-1 >= 0){
			posibles[index] = x-1;
			posibles[index+1] = y-1;
			index += 2;
			
		}
		
		posibles[index] = x-1;
		posibles[index+1] = y;
		index +=2;
		
		if(y+1 < matrixColumns){
			posibles[index] = x-1;
			posibles[index+1] = y+1;
			index += 2;
		}
	}
	
	if(y-1 >= 0){
		posibles[index] = x;
		posibles[index+1] = y-1;
		index += 2;
	}
	
	if(y+1 < matrixColumns){
		posibles[index] = x;
		posibles[index+1] = y+1;
		index += 2;
	}
	
	if(x+1 < matrixRows){
		if(y-1 >= 0){
			posibles[index] = x+1;
			posibles[index+1] = y-1;
			index += 2;
		}
		
		posibles[index] = x+1;
		posibles[index+1] = y;
		index +=2;
		
		if(y+1 < matrixColumns){
			posibles[index] = x+1;
			posibles[index+1] = y+1;
			index += 2;
		}
	}
	
	int salida = 0;
	for(int i=0;i<index && salida==0;i+=2){
		if(laberinto[posibles[i]][posibles[i+1]] != 0){
			reales[indexReal] = posibles[i];
			reales[indexReal+1] = posibles[i+1];
			indexReal += 2;
			if(laberinto[posibles[i]][posibles[i+1]] == 2 && rank == 0){
				//hemos encontrado la salida y somos el raton asi que vamos directamente a ella
				salida = 1;
			}
		}
	}
	
	//3) Elegimos una casilla aleatoria de la lista a la que movernos
	if(salida==0){
		int elegido = (rand() % (indexReal/2))*2;

		propio[0] = reales[elegido];
		propio[1] = reales[elegido+1];	
	} else{
		//este caso solo se da en el raton
		//en caso de tener la salida colocamos un -1 para comunicarselo al gato
		propio[0] = 0;
		propio[1] = matrixColumns-1;
	}
	
	/*
	for(int i=0;i<index;i+=2){
		printf("(%d,%d) ",posibles[i],posibles[i+1]);	
	}*/
	
}



//Llamado por cada proceso para rellenar de forma aleatoria un pedazo del laberinto
void asignarNumeros(int * local_buffer, int rank, int limite){
	
	int valor = 1;
	//rellenamos sector de 0s y 1s
	for(int i=0;i<limite;i++){

		if(valor == 1){
			//si el valor anterior fue un 1 puede ser un 0 o un 1
			valor = rand() % 2;
		} else{
			//si el valor anterior fue un 0 si o si usamos un 1
			valor = 1;
		}
		
		local_buffer[i] = valor;	
	}
}



//comprobamos si en los puntos del array donde hay cambio de proceso podrían darse dos 0s seguidos
//por ejemplo proc0 = 0 1 1 0 ; proc1 = 0 1 1 1 ; lab = 0 1 1 0 0 1 1 1
//se realiza una correccion lab = 0 1 1 0 1 1 1 1
void comprobarLimitesArray(int * buffer_recv, int size, int limite){
	
	//comprobamos limite de cada proceso
	for(int i=1;i<size;i++){
		
		//si tenemos doble 0 corregimos el ultimo
		if(buffer_recv[limite*i-1] == 0 && buffer_recv[limite*i] == 0){
			buffer_recv[limite*i] = 1;
		}
	}
}



//coloca los datos del array en la matriz
//0 muro
//1 camino
void crearLaberinto(int laberinto [matrixRows][matrixColumns], int * buffer_recv, int size, int limite){
	//indice para recorrer buffer_recv
	int index = 0;
	
	//para cada fila del laberinto
	for(int i=0;i<matrixRows;i++){
		//para cadad columna del laberinto
		for(int j=0;j<matrixColumns;j++){
			laberinto[i][j] = buffer_recv[index];
			index++;
		}
	}
	
	//Revisamos que las columnas tienen como minimo un 1
	int check;
	for(int j=0;j<matrixColumns;j++){
		check=0;
		for(int i=0;i<matrixRows;i++){
			check = check | laberinto[i][j];
		}
		
		//si no hay ningun 1 en la columna
		if(check==0){
			//ponemos al azar una casilla de la columna a 1
			laberinto[rand()%matrixRows][j] = 1;
		}
		
	}
	
	//Colocamos el raton, gato y salida
	//2 salida
	//4 raton (estos numeros es simplemente para que se diferencien mejor)
	//7 gato
	laberinto[0][0] = 4;
	laberinto[0][matrixColumns-1] = 2;
	laberinto[matrixRows-1][matrixColumns-1] = 7;
	
}







int main(int argc, char *argv[]) {
	
	//inicializacion de parametros necesarios para usar MPI y los calculos
	int laberinto[matrixRows][matrixColumns];
	int i,j,k, limite;
	
	int rank, size;
	int tagRaton = 123;
	int tagGato = 456;
	int raton = 0;
	int gato = 1;
	
	MPI_Status statusRaton, statusGato;
	//Deben inicializarse como request nulos
	//Esto es para evitar que haya problemas en la primera comunicacion entre el gato y el raton
	MPI_Request requestRaton = MPI_REQUEST_NULL;
	MPI_Request requestGato = MPI_REQUEST_NULL;
	
	MPI_Init (&argc, &argv); //iniciar MPI
	MPI_Comm_rank (MPI_COMM_WORLD, &rank);	//obtener id del proceso
	MPI_Comm_size (MPI_COMM_WORLD, &size);	//obtener numero de procesos
	
	//necesitamos al menos 2 procesos (gato y raton)
	if(size < 2){
		if(rank==root){
			printf("Este programa necesita al menos 2 procesos\n");
		}
		MPI_Abort(MPI_COMM_WORLD,1);
	}
	
	//dividimos el numero de casillas entre el numero de procesos
	//para ver cuantas casillas del laberinto debe generar cada proceso
	limite = totalMatrix / size;
	if(limite*size != totalMatrix){
		limite++;
	}
	
	//creamos seed aleatoria basada en tiempo y rango para cada proceso
	//se usa para crear el laberinto y mas tarde para elegir una casilla aleatoria a la que mover el raton y el gato
	srand( time(NULL) + rank );
	
	//un pedazo de tamanyo "limite" de array para cada proceso
	int buffer_send[limite*size];
	
	//cada proceso tiene su propio array de tamanyo limite
	int local_buffer[limite];
	
	//tamanyo "limite" de array para cada proceso
	int buffer_recv[limite*size];
	
	//Usamos scatter para repartir entre los distintos procesos "pedazos" del laberinto de tamanyo limite
	MPI_Scatter(buffer_send,limite,MPI_INT,local_buffer,limite,MPI_INT,root,MPI_COMM_WORLD);
	
		//Cada proceso rellena su array usando esta funcion
		asignarNumeros(local_buffer,rank,limite);
		
	//Cada proceso devuelve al proceso root los arrays para que reconstruya el laberinto
	MPI_Gather(local_buffer,limite,MPI_INT,buffer_recv,limite,MPI_INT,root,MPI_COMM_WORLD);
	
	//buffer para enviar el laberinto conztruido a todos los procesos
	int broadcast_buffer[totalMatrix];
	
	//root va a reconstruir el laberinto
	if(rank == root){
		
		//pero primero nos aseguramos de que el laberinto cumpla las condiciones necesarias
		comprobarLimitesArray(buffer_recv, size, limite);
		//una vez que las cumple si podemos construir el laberinto
		crearLaberinto(laberinto, buffer_recv, size, limite);
		
		k=0;
		for(i=0;i<matrixRows;i++){
			printf("| ");
			for(j=0;j<matrixColumns;j++){
				printf("%d | ",laberinto[i][j]);
				broadcast_buffer[k] = laberinto[i][j];
				k++;
			}
			printf("\n");
		}
		
	}
	
	//enviamos a todos los procesos el estado final del laberinto
	MPI_Bcast(broadcast_buffer,totalMatrix,MPI_INT,root,MPI_COMM_WORLD);
	
	//reconstruimos el laberinto en cada proceso basado en lo recibido en el broadcast
	k=0;
	for(i=0;i<matrixRows;i++){
		for(j=0;j<matrixColumns;j++){
			laberinto[i][j] = broadcast_buffer[k];
			k++;
		}
	}
	
	//ponemos un 1 en el lugar del gato y el raton
	//a partir de ahora ellos mismos colocaran cada vez en que casilla se encuentran
	laberinto[0][0] = 1;
	laberinto[matrixRows-1][matrixColumns-1] = 1;
	
	//creamos las variables necesarias para las interaccionesentre el gato y el raton
	
	//delay del raton
	int ratonDream;
	//delay del gato
	int gatoDream;
	//quien sea mas rapido lo marca a 1
	int faster;
	//buffer para guardar x e y del contrario
	int rival[2];
	//buffer para guardar x e y propias
	int propio[2];
	//flag para MPI_Iprobe
	int flag = 0;
	//para indicar quien ha ganado y perdido(raton gana si escapa, gato gana si lo atrapa)
	int ganado = 0;
	int perdido = 0;
	
	//para el proceso raton
	if(rank == raton){
		//delay del raton
		ratonDream = 3;
		//las casillas de inicio siempre son las mismas
		propio[0] = 0;
		propio[1] = 0;
		rival[0] = matrixRows-1;
		rival[1] = matrixColumns-1;
		
		//enviamos delay propio y recibimos el delay del contrario
		MPI_Send(&ratonDream,1,MPI_INT,gato,tagRaton,MPI_COMM_WORLD);
		MPI_Recv(&gatoDream,1,MPI_INT,gato,tagGato,MPI_COMM_WORLD,&statusGato);
		
		//revisamos quien es mas rapido
		//esto es necesario porque el mas rapido debe ejecutar una instruccion extra
		//si son igual de rapidos tambien es necesaria dicha instruccion
		if(ratonDream <= gatoDream){
			faster = 0;
		} else{
			faster = 1;
		}
		
		while((!perdido) && (!ganado)){
			//pedimos recibir las coordenadas del gato de forma preventiva
			MPI_Irecv(rival,2,MPI_INT,gato,tagGato,MPI_COMM_WORLD,&requestGato);
			
			MPI_Iprobe(gato,tagGato,MPI_COMM_WORLD,&flag,&statusGato);
			
			//delay
			sleep(ratonDream);	
			
			MPI_Iprobe(gato,tagGato,MPI_COMM_WORLD,&flag,&statusGato);

			//aseguramos que no haya problemas con envios por usar el array propio
			//request es nulo la primera vez para asegurar al sistema que no hay problema
			MPI_Wait(&requestRaton,&statusRaton);
			
			//el raton elige una posible casilla a la que moverse
			elegirCasilla(laberinto,propio,rank);
			
			//comunicamos las casillas al gato
			MPI_Isend(propio,2,MPI_INT,gato,tagRaton,MPI_COMM_WORLD,&requestRaton);
			
			//el mas rapido necesita ejecutar este wait
			if(faster){
				MPI_Wait(&requestGato,&statusGato);
			}
			
			//los distintos iprobes del codigo y este bucle sirven para revisar si hay mensajes pendientes
			//si por ejemplo el raton es 2 veces mas rapido, el gato tendra que leer 2 mensajes
			//para tener la posicion mas actual del raton
			MPI_Iprobe(gato,tagGato,MPI_COMM_WORLD,&flag,&statusGato);
			while(flag>0){
				MPI_Recv(rival,2,MPI_INT,gato,tagGato,MPI_COMM_WORLD,&statusGato);
				MPI_Iprobe(gato,tagGato,MPI_COMM_WORLD,&flag,&statusGato);
			}
			
			//print para mostrar cual es la posicion del gato segun el raton
			printf("Raton ve Gato: (%d,%d)  ",rival[0],rival[1]);
		
			if(propio[0] == rival[0] && propio[1] == rival[1]){
				//comprueba si esta en la misma casilla que el gato
				printf("Raton: (%d,%d)",propio[0],propio[1]);
				printf("\n");
								
				perdido = 1;
				propio[0] = -1;
				propio[1] = -1;
				MPI_Wait(&requestRaton,&statusRaton);
				//envia -1 al gato para indicar que ha atrapado al raton por si no se ha dado cuenta
				MPI_Send(propio,2,MPI_INT,gato,tagRaton,MPI_COMM_WORLD);
			} else if(rival[0] == -1){
				//si el gato envia -1 es que el raton ha sido atrapado
				perdido = 1;
			} else if(propio[0] == 0 && propio[1] == matrixColumns-1){
				//el raton alcanza la casilla de salida
				ganado = 1;
				printf("Raton: (%d,%d)",propio[0],propio[1]);
				printf("\n");

				propio[0] = -2;
				propio[1] = -2;
				MPI_Wait(&requestRaton,&statusRaton);
				//envia -2 al gato para indicar que el raton se ha escapado
				MPI_Send(propio,2,MPI_INT,gato,tagRaton,MPI_COMM_WORLD);
			}else{
				//caso comun
				printf("Raton: (%d,%d)",propio[0],propio[1]);
				printf("\n");
			}
		}
		
		//si el raton gana lo indica
		if(ganado){
			printf("\nEl Raton se ha escapado!\n");
		}

	} else if(rank == gato){
		//en general es igual que el del raton
		gatoDream = 9;
		propio[0] = matrixRows-1;
		propio[1] = matrixColumns-1;
		rival[0] = 0;
		rival[1] = 0;
		
		//primero recibe el delay del raton y luego envia el suyo
		MPI_Recv(&ratonDream,1,MPI_INT,raton,tagRaton,MPI_COMM_WORLD,&statusRaton);
		MPI_Send(&gatoDream,1,MPI_INT,raton,tagGato,MPI_COMM_WORLD);
		
		if(gatoDream < ratonDream){
			faster = 0;
		} else{
			faster = 1;
		}
		
		while((!perdido) && (!ganado)){
			MPI_Irecv(rival,2,MPI_INT,raton,tagRaton,MPI_COMM_WORLD,&requestRaton);
			MPI_Iprobe(raton,tagRaton,MPI_COMM_WORLD,&flag,&statusRaton);
			
			//delay
			sleep(gatoDream);	
			
			MPI_Iprobe(raton,tagRaton,MPI_COMM_WORLD,&flag,&statusRaton);
			

			MPI_Wait(&requestGato,&statusGato);
			
			elegirCasilla(laberinto,propio,rank);
			
			MPI_Isend(propio,2,MPI_INT,raton,tagGato,MPI_COMM_WORLD,&requestGato);

			if(faster){
				MPI_Wait(&requestRaton,&statusRaton);
			}
			
			MPI_Iprobe(raton,tagRaton,MPI_COMM_WORLD,&flag,&statusRaton);
			while(flag>0){
				MPI_Recv(rival,2,MPI_INT,raton,tagRaton,MPI_COMM_WORLD,&statusRaton);
				MPI_Iprobe(raton,tagRaton,MPI_COMM_WORLD,&flag,&statusRaton);
			}
			MPI_Iprobe(raton,tagRaton,MPI_COMM_WORLD,&flag,&statusRaton);
			
			//print para mostrar cual es la posicion del raton segun el gato
			printf("Gato ve Raton: (%d,%d)  ",rival[0],rival[1]);

			if(rival[0] == -2){
				//si el raton envia -2 es que el raton se ha escapado
				perdido = 1;
			} else if(propio[0] == rival[0] && propio[1] == rival[1]){
				//comprueba si esta en la misma casilla que el raton
				printf("Gato: (%d,%d)",propio[0],propio[1]);
				printf("\n");

				ganado = 1;
				propio[0] = -1;
				propio[1] = -1;
				MPI_Wait(&requestGato,&statusGato);
				MPI_Send(propio,2,MPI_INT,raton,tagGato,MPI_COMM_WORLD);
			} else if(rival[0] == -1){
				//si el raton envia -1 es que el raton ha sido atrapado
				ganado = 1;
			} else{
				//caso comun
				printf("Gato: (%d,%d)",propio[0],propio[1]);
				printf("\n");

			}

		}
		
		//si el gato ha ganado lo indica
		if(ganado){
			printf("\nEl Gato ha atrapado al raton!\n");
		}
	
	
	
		
	}
	
	MPI_Finalize();
	return 0;
	
}
