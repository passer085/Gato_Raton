package com.example.store_central.repositories;

import com.example.store_central.models.ProductModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

// consultas a una base de datos
@Repository
public interface IProductRepository extends JpaRepository<ProductModel, Long> {
    List<ProductModel> findByClienteId(Long clienteId);

}
