package com.example.store_central.services;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Request implements Comparable<Request> {
    private String clienteId;
    private String messageType;
    private String targetNodeId;
    private Long productId;
    private LocalDateTime timestamp;
    private String jsonMessage;

    public Request(String message) {
        try {
            if (message == null || message.isEmpty()) {
                throw new IllegalArgumentException("El mensaje está vaciio o nulo");
            }

            // usamos el delimitador
            String[] parts = message.split("#");

            // Asigna los valores a los atributos
            this.clienteId = parts[0];
            this.messageType = parts[1];
            this.targetNodeId = parts[2];
            this.productId = Long.valueOf(parts[3]);
            this.jsonMessage = parts[4];
            this.timestamp = LocalDateTime.parse(parts[parts.length - 1], DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        } catch (Exception e) {
            System.out.println("Se ha recibido un mal formato: " + e.getMessage());
            e.printStackTrace();
        }
    }



    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    @Override
    public int compareTo(Request other) {
        // Comparar por timestamp para la prioridad
        return this.timestamp.compareTo(other.timestamp);
    }

    public String getMessage() {
        return messageType + ":" + clienteId + ":" + targetNodeId + ":" + productId + ":" + jsonMessage + ":" + timestamp;
    }


    public String getClienteId() {
        return clienteId;
    }

    public void setClienteId(String clienteId) {
        this.clienteId = clienteId;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getTargetNodeId() {
        return targetNodeId;
    }

    public void setTargetNodeId(String targetNodeId) {
        this.targetNodeId = targetNodeId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getJsonMessage() {
        return jsonMessage;
    }

    public void setJsonMessage(String jsonMessage) {
        this.jsonMessage = jsonMessage;
    }
}
