package com.example.store_central.models;

import jakarta.persistence.*;

@Entity
@Table(name="Products_Global")
public class ProductModel {

    @Id
    @Column
    private Long clienteId;

    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private Long id;        // id del producto

    @Column
    private String nombreProducto;

    @Column
    private Long cantidadStock;

    @Column
    private Long precioUnitario;

    @Column
    private Long Categoria;

    @Column
    private String fechaultimaActualizacion;

    @Column
    private String historialMovimientos;

    @Column
    private String status;


    //-------------------- GETTERS y SETTERS --------------------//
    public Long getClienteId() {
        return clienteId;
    }

    public void setClienteId(Long clienteId) {
        this.clienteId = Long.valueOf(String.valueOf(clienteId));
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public Long getCantidadStock() {
        return cantidadStock;
    }

    public void setCantidadStock(Long cantidadStock) {
        this.cantidadStock = cantidadStock;
    }

    public Long getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(Long precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public Long getCategoria() {
        return Categoria;
    }

    public void setCategoria(Long categoria) {
        Categoria = categoria;
    }

    public String getFechaultimaActualizacion() {
        return fechaultimaActualizacion;
    }

    public void setFechaultimaActualizacion(String fechaultimaActualizacion) {
        this.fechaultimaActualizacion = fechaultimaActualizacion;
    }

    public String getHistorialMovimientos() {
        return historialMovimientos;
    }

    public void setHistorialMovimientos(String historialMovimientos) {
        this.historialMovimientos = historialMovimientos;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}

