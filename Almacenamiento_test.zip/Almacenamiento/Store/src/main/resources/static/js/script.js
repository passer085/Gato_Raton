document.getElementById('methodSelector').addEventListener('change', toggleBodySection);
document.getElementById('sendRequestButton').addEventListener('click', sendRequest);
document.getElementById("getProductsButton").addEventListener("click", function() {
    fetch("http://localhost:8081/store")
        .then(response => response.json())
        .then(data => {
            console.log(data);  // Verifica los datos que recibes
            displayDataInTable(data);  // Llama a una función para mostrar los datos
        })
        .catch(error => console.error('Error:', error));
});

function displayDataInTable(data) {
    const tableBody = document.getElementById("productsTable").getElementsByTagName('tbody')[0];
    tableBody.innerHTML = "";  // Limpia la tabla antes de agregar nuevos datos

    data.forEach(product => {
        const row = tableBody.insertRow();
        row.insertCell(0).textContent = product.clienteId;
        row.insertCell(1).textContent = product.id;
        row.insertCell(2).textContent = product.nombreProducto;
        row.insertCell(3).textContent = product.cantidadStock;
        row.insertCell(4).textContent = product.precioUnitario;
        row.insertCell(5).textContent = product.Categoria;
        row.insertCell(6).textContent = product.fechaultimaActualizacion;
        row.insertCell(7).textContent = product.historialMovimientos;
        row.insertCell(8).textContent = product.status;
    });
}

function toggleBodySection() {
    const method = document.getElementById('methodSelector').value;
    const bodySection = document.getElementById('bodySection');

    if (method === 'POST' || method === 'PUT') {
        bodySection.style.display = 'block';
    } else {
        bodySection.style.display = 'none';
    }
}

async function sendRequest() {
    const method = document.getElementById('methodSelector').value;
    const url = document.getElementById('urlInput').value;
    const body = document.getElementById('bodyInput').value;

    const options = {
        method: method,
        headers: { 'Content-Type': 'application/json' }
    };

    if (method === 'POST' || method === 'PUT') {
        options.body = JSON.stringify(JSON.parse(body)); // Parse JSON body if available
    }

    try {
        const response = await fetch(url, options);
        const data = await response.json();
        document.getElementById('responseOutput').textContent = JSON.stringify(data, null, 2);
    } catch (error) {
        document.getElementById('responseOutput').textContent = `Error: ${error.message}`;
    }
}
