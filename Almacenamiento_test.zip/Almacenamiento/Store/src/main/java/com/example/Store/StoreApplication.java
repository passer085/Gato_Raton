package com.example.Store;

import com.example.Store.services.TimeSyncService;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StoreApplication {

	@Autowired
	private TimeSyncService timeSyncService;

	public static void main(String[] args) {
		SpringApplication.run(StoreApplication.class, args);
	}

	@PostConstruct
	public void init() {
		timeSyncService.syncTime(); // Ejecutmaos el reloj, habria que hacer en un hilo probalbly
	}
}
