package com.example.cliente_zhong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteZhongApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteZhongApplication.class, args);
	}

}
