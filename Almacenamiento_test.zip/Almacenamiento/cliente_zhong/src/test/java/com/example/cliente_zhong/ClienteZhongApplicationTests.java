package com.example.cliente_zhong;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteZhongApplicationTests {

	@Test
	void contextLoads() {
	}

}
