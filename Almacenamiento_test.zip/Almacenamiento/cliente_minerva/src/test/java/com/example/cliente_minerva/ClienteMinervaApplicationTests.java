package com.example.cliente_minerva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteMinervaApplicationTests {

	@Test
	void contextLoads() {
	}

}
