package com.example.cliente_minerva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteMinervaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteMinervaApplication.class, args);
	}

}
