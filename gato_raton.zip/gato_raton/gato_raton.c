//mpicc gato_raton.c -o gato_raton -lm
//mpirun -np nprocesos gato_raton


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>

#define root 0

#define matrixSize 4

#define totalMatrix (matrixSize*matrixSize)

void mover(int laberinto[matrixSize][matrixSize], int propio[2], int rank){
	//1) averiguar a que casillas me puedo mover por posibles limites de la matriz
	int posibles[8*2];
	int reales[8*2];
	int index = 0;
	int indexReal = 0;
	int x = propio[0];
	int y = propio[1];

	if(x-1 >= 0){
		if(y-1 >= 0){
			posibles[index] = x-1;
			posibles[index+1] = y-1;
			index += 2;
			
		}
		
		posibles[index] = x-1;
		posibles[index+1] = y;
		index +=2;
		
		if(y+1 < matrixSize){
			posibles[index] = x-1;
			posibles[index+1] = y+1;
			index += 2;
		}
	}
	
	if(y-1 >= 0){
		posibles[index] = x;
		posibles[index+1] = y-1;
		index += 2;
	}
	
	if(y+1 < matrixSize){
		posibles[index] = x;
		posibles[index+1] = y+1;
		index += 2;
	}
	
	if(x+1 < matrixSize){
		if(y-1 >= 0){
			posibles[index] = x+1;
			posibles[index+1] = y-1;
			index += 2;
		}
		
		posibles[index] = x+1;
		posibles[index+1] = y;
		index +=2;
		
		if(y+1 < matrixSize){
			posibles[index] = x+1;
			posibles[index+1] = y+1;
			index += 2;
		}
	}
	
	if(rank == root){
		int salida = 0;
		//2) El RATON va a casillas que no sean un 0(muro)
		//si encuentra el 2(salida)
		for(int i=0;i<index && salida==0;i+=2){
			if(laberinto[posibles[i]][posibles[i+1]] != 0 && laberinto[posibles[i]][posibles[i+1]] != 2){
				reales[indexReal] = posibles[i];
				reales[indexReal+1] = posibles[i+1];
				indexReal += 2;
			} else if(laberinto[posibles[i]][posibles[i+1]] == 2){
				//hemos encontrado la salida asi que vamos directamente a ella
				salida = 1;
			}
		}
		
		//3) Si no tenemos disponible la salida elegimos una casilla aleatoria de la lista a la que movernos
		if(salida==0){
			srand(time(NULL));
			int elegido = (rand() % (indexReal/2))*2;

			propio[0] = reales[elegido];
			propio[1] = reales[elegido+1];	
		} else{
			//en caso de tener la salida colocamos un -1 para comunicarselo al gato
			propio[0] = -1;
			propio[1] = -1;
		

		}
	} else {
		//2) El GATO va a casillas que no sean un 0
		for(int i=0;i<index;i+=2){
			if(laberinto[posibles[i]][posibles[i+1]] != 0){	
				reales[indexReal] = posibles[i];
				reales[indexReal+1] = posibles[i+1];
				indexReal += 2;
			}
		}

		//3) Elegimos una casilla aleatoria de la lista a la que movernos
		srand(time(NULL));
		int elegido = (rand() % (indexReal/2))*2;

		propio[0] = reales[elegido];
		propio[1] = reales[elegido+1];
		
	}
	
}


void asignarNumeros(int * local_buffer, int rank, int sector){
	//creamos seed unica para cada proceso basada en tiempo y rango
	srand( time(NULL) + rank );
	
	int last = 1;
	//rellenamos sector de 0s y 1s
	for(int i=0;i<sector;i++){
		if(last == 1){
			last = rand() % 2;
		} else{
			last = 1;
		}
		
		local_buffer[i] = last;	
	}
}

//coloca los datos del array recibido en la matriz
//0 muro
//1 camino
void crearLaberinto(int laberinto [matrixSize][matrixSize], int * buffer_recv, int raiz, int porcion, int sector, int size){
	//para cada proceso
	for(int i=0;i<size;i++){
		//filas de su sector
		for(int j=0;j<porcion;j++){
			//columnas de su sector
			for(int k=0;k<porcion && (((i/raiz)*porcion)+j) < matrixSize && (((i%raiz)*porcion)+k) < matrixSize;k++){
				laberinto[((i/raiz)*porcion)+j][((i%raiz)*porcion)+k] = buffer_recv[i*sector + j*porcion + k];
			}
		}
	}
	
}


//comprueba que haya caminos entre todos los sectores
//en caso de no haberlos los corrige
void arreglarLaberinto(int laberinto[matrixSize][matrixSize], int raiz, int porcion, int sector, int size){
	
	//1) Conexiones entre todos los sectores
	int x,y,i,j;
	//para cada proceso
	for(i=0;i<size;i++){
		//esquinas de cada zona
		//comprobar que 1) no se salen 2) su valor + 1 no es mayor o igual que matrixSize
		x = ((i/raiz)*porcion)+(porcion-1);
		y = ((i%raiz)*porcion)+(porcion-1);
		//aseguramos que la esquina y al menos haya una casilla conjunta de cada sector vecino con un 1
		//siempre que no nos salgamos de la matriz
		if(x+1 < matrixSize && y+1 < matrixSize){
			laberinto[x+1][y+1] = 1;
		}
		if(x+1 < matrixSize){
			laberinto[x+1][y] = 1;
		}
		if(y+1 < matrixSize){
			laberinto[x][y+1] = 1;
		}
		if(x < matrixSize && y < matrixSize){
			laberinto[x][y] = 1;
		}
		
	}
	
	//2) Todas las columnas tienen minimo un 1
	int check;
	for(j=0;j<matrixSize;j++){
		check=0;
		for(i=0;i<matrixSize;i++){
			check = check | laberinto[i][j];
		}
		//si no hy ninguna
		if(check==0){
			//ponemos al azar una casilla de la columna a 1
			laberinto[rand()%matrixSize][j] = 1;
		}
		
	}
	
	//3)Colocamos la salida, el raton y el gato
	//2 salida
	//4 raton (los numeros estos es simplemente para que se vean mejor)
	//7 gato
	laberinto[0][0] = 4;
	laberinto[0][matrixSize-1] = 2;
	laberinto[matrixSize-1][matrixSize-1] = 7;
}



int main(int argc, char *argv[]) {
	int laberinto[matrixSize][matrixSize];
	int i,j,k,raiz,porcion,sector;
	
	int rank, size;
	int tagRaton,tagGato,raton,gato;
	MPI_Status statusRaton, statusGato;
	MPI_Request requestRaton = MPI_REQUEST_NULL;
	MPI_Request requestGato = MPI_REQUEST_NULL;
	
	MPI_Init (&argc, &argv); //iniciar MPI
	MPI_Comm_rank (MPI_COMM_WORLD, &rank);	//obtener id del proceso
	MPI_Comm_size (MPI_COMM_WORLD, &size);	//obtener numero de procesos
	
	raiz = sqrt(size);
	
	//necesitamos al menos 2 procesos
	if(size < 2){
		MPI_Abort(MPI_COMM_WORLD,1);
	}
	
	//si el numero de procesos no nos permite una correcta division de la matriz
	if(raiz*raiz != size){
		MPI_Abort(MPI_COMM_WORLD,1);
	}
	
	tagRaton=123; tagGato=456; raton=0; gato=1;
	
	//Calculo del inicio y tamaño de seccion de matriz a repartir
	porcion = sqrt(totalMatrix / size);
	
	//revisar si el numero es exacto
	//si no lo es le sumamos 1 para asegurarnos de cubrir toda la matriz
	if(porcion*porcion*size != totalMatrix){
		porcion += 1;
	}
	sector = porcion * porcion;
	
	//un sector por cada proceso
	int buffer_send[sector*size];
	
	//un sector
	int local_buffer[sector];
	
	//un sector por cada proceso
	int buffer_recv[sector*size];
	
	MPI_Scatter(buffer_send,sector,MPI_INT,local_buffer,sector,MPI_INT,root,MPI_COMM_WORLD);
	
		asignarNumeros(local_buffer,rank,sector);
	
	MPI_Gather(local_buffer,sector,MPI_INT,buffer_recv,sector,MPI_INT,root,MPI_COMM_WORLD);
	
	//para pasar a todos los procesos el resultado final del laberinto
	int broadcast_buffer[totalMatrix];
	
	//la raiz costruye el laberinto
	if(rank == root){

		crearLaberinto(laberinto, buffer_recv, raiz, porcion, sector, size);
		arreglarLaberinto(laberinto, raiz, porcion, sector, size);
		
		//mostramos el laberinto
		k=0;
		for(i=0;i<matrixSize;i++){
			printf("| ");
			for(j=0;j<matrixSize;j++){
				printf("%d | ",laberinto[i][j]);
				broadcast_buffer[k] = laberinto[i][j];
				k++;
			}
			printf("\n");
		}
		
	}
	
	//pasamos el laberinto al resto de procesos
	MPI_Bcast(broadcast_buffer,totalMatrix,MPI_INT,root,MPI_COMM_WORLD);
	
	//cada proceso reconstruye el laberinto
	k=0;
	for(i=0;i<matrixSize;i++){
		for(j=0;j<matrixSize;j++){
			laberinto[i][j] = broadcast_buffer[k];
			k++;
		}
	}
	
	
	//delay
	int dream;
	//buffer para guardar coordenadas del contrario
	int rival[2];
	//buffer para guardar coordenadas propias
	int propio[2];
	
	//y ahora si, mandamos al raton(0) y al gato(1)
	if(rank == root){
		
		//raton
		//inicializamos variables
		propio[0] = 0;
		propio[1] = 0;
		rival[0] = matrixSize-1;
		rival[1] = matrixSize-1;
		dream = 2;	
		
		//si el gato atrapa al raton manda un -1
		//si el raton se escapa manda un -1
		while(rival[0] != -1 && propio[0] != -1){
			
			//pedimos de forma preventiva la posicion del gato
			MPI_Irecv(rival,2,MPI_INT,gato,tagGato,MPI_COMM_WORLD,&requestGato);
			
			//delay
			sleep(dream);
			
			//nos aseguramos de que el gato ya ha recibido las nuevas coordenadas
			//la primera vez se ignora por el valor que le asignamos al request
			MPI_Wait(&requestRaton,&statusRaton);
	
			//nos movemos			
			mover(laberinto,propio,rank);
			
			//mandamos al gato la nueva posicion
			MPI_Isend(propio,2,MPI_INT,gato,tagRaton,MPI_COMM_WORLD,&requestRaton);
			
			//esperamos a tener la posicion mas actual del gato si aun no la ha recibido
			MPI_Wait(&requestGato,&statusGato);

			//este print muestra las coordenadas del gato desde el punto de vista del raton
			//printf("Raton ve Gato: (%d,%d)  ",rival[0],rival[1]);
			 if(propio[0] != -1 && rival[0] != -1){
				//indicamos a donde nos movemos
				printf("Raton: (%d,%d)\n",propio[0],propio[1]);
			}
			//si el raton y el gato estan en la misma casilla
			if(propio[0] == rival[0] && propio[1] == rival[1]){
				//aseguramos el envio de las coordenadas al gato
				MPI_Wait(&requestRaton,&statusRaton);
				//marcamos el gato a -1 para indicar que ha atrapado al raton
				rival[0] = -1;
				rival[1] = -1;
				MPI_Send(propio,2,MPI_INT,gato,tagRaton,MPI_COMM_WORLD);
			}

		}
		
		//si el raton se escapa lo anuncia
		if(propio[0] == -1){
			//damos coordenadas de casilla de salida y anunciamos el escape
			printf("Raton: (0,%d)\nEl Raton se ha escapado!\n",(matrixSize-1));
		}
		
	} else if(rank==1){
		//gato
		//inicializamos variables
		propio[0] = matrixSize-1;
		propio[1] = matrixSize-1;
		rival[0] = 0;
		rival[1] = 0;
		dream = 4;
		//si el raton manda un -1 es que se ha escapado
		//si el gato atrapa al raton manda un -1
		while(rival[0] != -1 && propio[0] != -1){
			
			//pedimos de forma preventiva la posicion del raton
			MPI_Irecv(rival,2,MPI_INT,raton,tagRaton,MPI_COMM_WORLD,&requestRaton);
			
			//delay
			sleep(dream);
		
			//nos aseguramos de que el raton ya ha recibido las nuevas coordenadas
			//la primera vez se ignora por el valor que le asignamos al request
			MPI_Wait(&requestGato,&statusGato);
		
			//nos movemos
			mover(laberinto,propio,rank);
			
			//mandamos al raton la nueva posicion
			MPI_Isend(propio,2,MPI_INT,raton,tagGato,MPI_COMM_WORLD,&requestGato);
			
			//intentamos conseguir la posicion mas actual del raton
			MPI_Wait(&requestRaton,&statusRaton);
			
			//este print muestra las coordenadas del raton desde el punto de vista del gato
			//printf("Gato ve Raton: (%d,%d)  ",rival[0],rival[1]);
			if(propio[0] != -1 && rival[0] != -1){
				//indicamos a donde nos movemos
				printf("Gato: (%d,%d)\n",propio[0],propio[1]);
			}
			
			//si el raton y el gato estan en la misma casilla
			if(propio[0] == rival[0] && propio[1] == rival[1]){
				//aseguramos el envio de las coordenadas al gato
				MPI_Wait(&requestGato,&statusGato);
				//marcamos el gato a -1 para indicar que ha atrapado al raton
				propio[0] = -1;
				propio[1] = -1;
			}

		}
		//si el gato atrapa al raton lo anuncia
		if(rival[0] != -1){
			printf("El Gato ha atrapado al Raton!\n");	
		}
	}

	MPI_Finalize();
	return 0;

}


/*
 		for(i=0;i<matrixSize;i++){
			printf("| ");
			for(j=0;j<matrixSize;j++){
				printf("%d | ",laberinto[i][j]);
			}
			printf("\n");
		}
*/


